x = 99
def f():
  print('x in my imported module is: ', x)
