from machine import RTC

rtc = RTC()
print(rtc.now())
