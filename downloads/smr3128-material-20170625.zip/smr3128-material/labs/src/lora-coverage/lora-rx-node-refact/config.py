""" LoPy LoRa Coverage configuration options """

WIFI_HOTSPOT_SSID = 'mrandroid'
WIFI_HOTSPOT_WPA2 = 'eatmenow'
GPSD_HOST = "192.168.43.1"
GPSD_PORT = 2947

LOG_PATH = '/flash/log'
