#!/bin/bash
# ------------------------------------------------------------
# This script execute rshell
# Author: Marco Rainone
# Ver. 1.0, 2017/04/01
#
rshell -p /dev/ttyUSB0
