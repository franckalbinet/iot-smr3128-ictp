import socket

# time module for sleep() function
import time

# Define the values to be used for the Server
SERVERADDR, SERVERPORT = '2001:760:2e0b:1720:9a01:a7ff:fe8c:da8f', 9999

# try to detect whether IPv6 is supported at the present system
if not socket.has_ipv6:
    raise Exception("Local machine has no IPv6 support enabled")

#Prepare the address and port needed to make the server listen
addrs = socket.getaddrinfo(SERVERADDR, SERVERPORT, socket.AF_INET6, 0, socket.SOL_TCP)
entry0 = addrs[0]
sockaddr = entry0[-1]


s = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)
s.bind(sockaddr)
s.listen(1)
print ("server opened socket connection:", s, ", address: '%s'" % sockaddr[0])

# Wait for a client to connect
conn, addr = s.accept()
time.sleep(1)
print ('Server: Connected by', addr)

# Receive data from client
data = conn.recv(1024)
print("Data Received from Client: ",data)

# Send data back in Uppercase Letters as an answer
conn.send(data.upper())
print("Data Sent to Client: ",data.upper())

