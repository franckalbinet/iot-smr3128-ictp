import socket
import sys

# USE: python Client.py Message to be sent to server

# Use any IPv6 address of the Server
SERVERADDR, SERVERPORT = "::1", 9999

while(1):

    # Create a socket (SOCK_STREAM means a TCP socket)
    with socket.socket(socket.AF_INET6, socket.SOCK_STREAM) as sock:
        # Connect to server
        sock.connect((SERVERADDR, SERVERPORT))

        # Request the text to be sent to the server
        data = input("Enter the message to server (temperature | humidity | status): ")

        # Send data to server
        sock.sendall(bytes(data, "utf-8"))

        # Receive data from the server and shut down
        received = str(sock.recv(1024), "utf-8")

    print("Sent:     {}".format(data))
    print("Received: {}".format(received))
