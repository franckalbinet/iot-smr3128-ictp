import socket

# time module for sleep() function
import time

# Define the values to be used for the Server
SERVERADDR, SERVERPORT = '::1', 9999
temperature = "30 Degrees Celsius"
humidity = "45%"
status = "OK code 000"
error_msg = "ERROR: Unknown message"

# try to detect whether IPv6 is supported at the present system
if not socket.has_ipv6:
    raise Exception("Local machine has no IPv6 support enabled")

#Prepare the address and port needed to make the server listen
addrs = socket.getaddrinfo(SERVERADDR, SERVERPORT, socket.AF_INET6, 0, socket.SOL_TCP)
entry0 = addrs[0]
sockaddr = entry0[-1]


s = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)
s.bind(sockaddr)
s.listen(1)
print ("server opened socket connection:", s, ", address: '%s'" % sockaddr[0])

while (1):
    # Wait for a client to connect
    conn, addr = s.accept()
    time.sleep(1)
    print ('**********************************')
    print ('Server: Connected by', addr)
    print ('**********************************\n')

    # Receive data from client
    data_rx = conn.recv(1024)
    data = data_rx.decode('utf-8')
    print("REQUEST Received from Client: ",data_rx)

    # Process data received and send a proper answer
    if data == "temperature":
        conn.send(bytes(temperature, "utf-8"))
        print("Temperature Sent to Client: ",temperature)
    elif data == "humidity":
        conn.send(bytes(humidity, "utf-8"))
        print("Humidity Sent to Client: ",humidity)
    elif data == "status":
        conn.send(bytes(status, "utf-8"))
        print("Status Sent to Client: ",status)
    else:
        conn.send(bytes(error_msg, "utf-8"))
        print("ERROR Sent to Client: ",error_msg)



